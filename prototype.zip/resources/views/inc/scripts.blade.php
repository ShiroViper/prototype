{{-- 
<script type="text/javascript" src="{{asset('js/jquery.slim.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/bootstrap.bundle.min.js')}}"></script>
<script type="text/javascript" src="{{ asset('js/scripts.js') }} "></script> --}}

<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="{{ asset('js/scripts.js') }}"></script>