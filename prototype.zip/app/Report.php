<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Report extends Model
{
    // Table
    protected $table = 'reports';

    // timestamps
    public $timestamps = true;
}
