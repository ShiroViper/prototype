<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Process extends Model
{
    // Table 
    protected $table = 'processes';
    // Primary Key
    // public $table = '';

    // timestamps
    public $timestamps = true;

    // public function user(){
    //     return $this->belongs
    // }
    // public function request(){

    // }
}
