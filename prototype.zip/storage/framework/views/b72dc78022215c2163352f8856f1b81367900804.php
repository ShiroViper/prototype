





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Alkansya Login</title>

    <!-- CSRF Token -->
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

	<!-- Icon -->
	<link rel="icon" href="<?php echo e(asset('img/favicon.ico')); ?>" type="image/x-icon" />
	
	<!-- Page Title -->
	<?php echo $__env->yieldContent('title'); ?>

	<!-- Fonts -->
	<link rel="dns-prefetch" href="//fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400|Open+Sans:300,400" rel="stylesheet">

	<!-- Styles -->
	<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <div class="main-login">
        <div class="main-login-container mx-auto">
            <div class="container">
                <div class="d-flex flex-column align-items-center">
                    <div class="login-logo m-3">
                        <a href="/">
                            <img src="<?php echo e(asset('img/logo.png')); ?>" alt="" class="img-fluid">
                        </a>
                    </div>
                    <h5 class="login-title">Sign in</h5>

                    
                    <?php if($message = Session::get('error')): ?>
                        <div class="text-center pt-2">
                            <span class="text-danger text-center"><strong><?php echo e($message); ?></strong></span><br>
                            <small class="text-danger">Incorrect Email or Password</small>
                        </div>
                    <?php endif; ?>

                    <div class="login-form-container w-100 clearfix">
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <small>Email</small>
                            <input name="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                            <?php if( $errors->has('email') ): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div>
                            <?php endif; ?>

                            </div>
                            <div class="form-group">
                                <small>Password</small>
                                <input name="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" value="<?php echo e(isset($message) ? '' : old('password')); ?>" autofocus required>
                                <?php if( $errors->has('password') ): ?>
                                    <div class="invalid-feedback"><?php echo e($errors->first('password')); ?></div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="pt-3 cleafix">
                                
                                <button type="submit" class="btn btn-primary btn-block px-4">Login</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>