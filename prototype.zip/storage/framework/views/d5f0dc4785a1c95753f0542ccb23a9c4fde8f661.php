<?php $__env->startSection('title'); ?>
<title>Alkansya - Manage Users</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h3 class="mt-2">Manage Accounts</h3>
<div class="table-responsive">
    <table class="table table-hover mt-3">
        <thead>
            <tr>
                <th>Account ID</th>
                <th>Complete Name</th>
                <th>Email</th>
                <th>Role</th>
                
            </tr>
        </thead>
        <tbody>
            <?php if(count($users) > 0): ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if( $user->user_type == 1 ): ?>
                            
                            <tr class="manage-accounts clickable-row table-warning" data-href="/admin/users/<?php echo e($user->id); ?>">
                            <!-- manage-accounts clickable-row text-muted font-weight-lighter font-italic -->
                        <?php else: ?>
                            <tr class="manage-accounts clickable-row" data-href="/admin/users/<?php echo e($user->id); ?>">
                        <?php endif; ?>
                                <td><?php echo e($user->id); ?></td>
                                <td>
                                    <?php
                                    echo $user->lname.", ".$user->fname." ".$user->mname;
                                    ?>
                                </td>
                                <td><?php echo e($user->email); ?></td>
                                <td>
                                    <?php if( $user->user_type == 1 ): ?>
                                        Collector
                                    <?php else: ?>
                                        Member
                                    <?php endif; ?>
                                </td>
                                
                            </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <tr>
                <td colspan="100%" class="text-center"><h4 class="text-muted">No Entries Found</h4></td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="d-flex justify-content-center mt-3">
    <?php echo e($users->links()); ?>

</div>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/scripts.js')); ?>" defer></script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>