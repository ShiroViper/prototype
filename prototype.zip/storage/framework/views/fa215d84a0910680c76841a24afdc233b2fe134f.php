<?php $__env->startSection('title'); ?>

<title>Welcome to Alkansya</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<div class="main-feature">
    <div class="container">
        <div class="main-header">
            <div class="row">
                <div class="col col-md col-lg">
                    <div class="text-primary">
                        <span class="welcome-title header pr-2">Welcome to</span> <span class="brand-title-header">ALKANSYA</span>
                    </div>
                    <div class="featured-desc lead my-3">
                        <p>
                            Join us and be part of an organization that aims to help people in their financial needs. 
                        </p>
                        <p>Alkansya is a mobile responsive web application system that is used to gain access to features like account management, money transfer, deposit, loan and payment. Managed by a non-profit organization located in Compostela, Cebu, Alkanysa turns the manual procedure of sinking fund into a process that is systematic with the help of the internet.</p>
                    </div>
                    <div class="row py-3">
                        <div class="col col-sm col-md col-lg-10 col-xl-6">
                            

                            <!-- Button trigger modal -->
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#member">
                                I want to be a member
                            </button>
                            <a href="/login" class="btn btn-outline-primary ml-3">Members Sign In</a>
                        </div>
                    </div>
                </div>
                <div class="col col-md-4 col-lg-6 featured-img">
                    <img src="img/img.png" alt="" class="img-fluid">
                </div>
            </div>
        </div>
        
    </div>
</div>
  
  <!-- Modal -->
<div class="modal fade" id="member" tabindex="-1" role="dialog" aria-labelledby="memberLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="memberLabel">Be part of us</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container">
                    <h6>Please enter your credentials</h6>
                    <?php echo Form::open(['action'=> 'MemberRequestController@memberRequest', 'method'=>'POST']); ?>

                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <?php echo e(Form::label('lname', 'Last Name')); ?>

                            <?php echo e(Form::text('lname', '', ['class' => $errors->has('lname') ? 'form-control is-invalid' : 'form-control'])); ?>

                            <?php if($errors->has('lname')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('lname')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <?php echo e(Form::label('fname', 'First Name')); ?>

                            <?php echo e(Form::text('fname', '', ['class' => $errors->has('fname') ? 'form-control is-invalid' : 'form-control'])); ?>

                            <?php if($errors->has('fname')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('fname')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <?php echo e(Form::label('mname', 'Middle Name')); ?>

                            <small class="text-muted">(Optional)</small>
                            <?php echo e(Form::text('mname', '', ['class' => $errors->has('mname') ? 'form-control is-invalid' : 'form-control'])); ?>

                            <?php if($errors->has('mname')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('mname')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <?php echo e(Form::label('cell_num', 'Contact Number')); ?>

                            <?php echo e(Form::text('cell_num', '', ['class' => $errors->has('cell_num') ? 'form-control is-invalid' : 'form-control'])); ?>

                            <?php if($errors->has('cell_num')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('cell_num')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <?php echo e(Form::label('email', 'Email')); ?>

                            <?php echo e(Form::email('email', '', ['class' => $errors->has('email') ? 'form-control is-invalid' : 'form-control'])); ?>

                            <?php if($errors->has('email')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <?php echo e(Form::label('address', 'Complete Address', ['class' => 'mb-0'])); ?>

                            <div class="mb-2"><small class="text-muted">Street number, Barangay, City/Town, Province, Philippines, Zip Code</small></div>
                            <?php echo e(Form::textarea('address', '', ['class' => $errors->has('address') ? 'form-control is-invalid' : 'form-control', 'rows' => 2])); ?>

                            <?php if($errors->has('address')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('address')); ?></div>
                            <?php endif; ?>
                        </div>

                        <small class="text-muted"><b>Note</b>: Please wait for our administrator to verify your request.</small>
                        <div class="pt-3">
                            <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary btn-block mb-3'])); ?>

                        </div>
                    <?php echo Form::close(); ?>

                    
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    <?php if(count($errors) > 0): ?>
        $('#member').modal('show');
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>