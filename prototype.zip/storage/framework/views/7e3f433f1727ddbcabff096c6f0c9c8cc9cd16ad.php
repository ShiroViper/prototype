<?php if(auth()->guard()->guest()): ?>
    <div class="navbar navbar-expand-md navbar-light bg-light  welcome-nav border-bottom">
        <div class="container">
            <div class="navbar-brand" style="width: 40%; max-width: 200px;">
            <a href="/">
                <img src="<?php echo e(asset('img/logo.png')); ?>" alt="" class="img-fluid">
            </a>
            </div>
            <button class="navbar-toggler" type="button"  data-toggle="collapse" data-target="#indexNav" aria-controls="indexNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="indexNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item<?php echo e(isset($active) && $active == 'welcome' ? ' active' : ''); ?>">
                        <a href="/" class="nav-link h6 mb-0">Home</a>
                    </li>
                    <li class="nav-item<?php echo e(isset($active) ? '' : ' active'); ?>">
                        <a href="/login" class="nav-link h6 mb-0">Sign In</a>
                    </li>
                    <li class="nav-item<?php echo e(isset($active) && $active == 'about' ? ' active' : ''); ?>">
                        <a href="/about" class="nav-link h6 mb-0">Who we are</a>
                    </li>
                    
                </ul>
            </div>
        </div>
    </div>
<?php else: ?>
<nav class="navbar navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand" href="#" style="width: 40%; max-width: 200px;">
        <img src="<?php echo e(asset('img/logo.png')); ?>" class="img-fluid" alt="logo">
        </a>
        <div class="current-user-container ml-auto">
            <div class="dropdown">
                <a class="h6 text-decoration-none text-capitalize dropdown-toggle" href="#" role="button" id="currentUser" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                   <?php echo e(Auth::user()->lname); ?>, <?php echo e(Auth::user()->fname); ?> 
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="currentUser">
                    
                    
                    
                    <?php if(Auth::user()->user_type == 2): ?>
                        <a class="dropdown-item" href="/admin/profile">Profile</a>
                    <?php elseif(Auth::user()->user_type == 1): ?>
                        <a class="dropdown-item" href="/collector/profile">Profile</a>
                    <?php else: ?>
                        <a class="dropdown-item" href="/member/profile">Profile</a>
                    <?php endif; ?>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</nav>

<nav class="navbar navbar-dark bg-dark border-bottom navbar-expand-xl">
    <div class="container">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#menuNav" aria-controls="menuNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="menuNav">
            <ul class="navbar-nav">
            
                
                <?php if(Auth::user()->user_type == 2): ?>
                    <li class="nav-item px-3 h6">
                        
                        <a class="nav-link<?php echo e($active == 'dashboard' ? ' active callout' : ''); ?>" href="/admin/dashboard">Dashboard</a>
                    </li>
                    <li class="nav-item px-3 h6">
                        <a class="nav-link<?php echo e($active == 'create' ? ' active callout' : ''); ?>" href="/admin/users/create">
                            <!-- <span class="sr-only">(current)</span> -->
                            Add Member
                        </a>
                    </li>
                    <li class="nav-item px-3 h6">
                        <a class="nav-link<?php echo e($active == 'manage' ? ' active callout' : ''); ?>" href="/admin/users">Manage</a>
                    </li>
                    <li class="nav-item px-3 h6">
                        <a class="nav-link<?php echo e($active == 'sched' ? ' active callout' : ''); ?>" href="/admin/calendar">Calendar</a>
                    </li>
                    <li class="nav-item px-3 h6">
                        <a class="nav-link<?php echo e($active == 'requests' ? ' active callout' : ''); ?>" href="/admin/requests">Requests 
                            <?php if(isset($counter) && $counter > 0): ?>
                                <span class="badge badge-pill badge-danger">
                                    <?php echo e($counter); ?>

                                </span>
                            <?php endif; ?>
                        </a>
                    </li>
                    
                    <li class="nav-item px-3 h6">
                        <a class="nav-link <?php echo e($active == 'deliquent' ? 'active callout' : ''); ?> " href="/admin/deliquent">Deliquent</a>
                    </li>
                    <li class="nav-item px-3 h6">
                        <a class="nav-link" href="#">Receipts</a>
                    </li>
                    
                    
                
                <?php elseif(Auth::user()->user_type == 1): ?>
                    <li class="nav-item px-3 h6">
                        <a class="nav-link<?php echo e($active == 'dashboard' ? ' active callout' : ''); ?>" href="/collector/transaction">Transactions</a>
                    </li>
                    <li class="nav-item px-3 h6">
                        <a class="nav-link<?php echo e($active == 'collect' ? ' active callout' : ''); ?>" href="/collector/transaction/create">Collection</a>
                    </li>
                    <li class="nav-item px-3 h6">
                        <a class="nav-link<?php echo e($active == 'deliquent' ? ' active callout' : ''); ?>" href="/collector/deliquent">Deliquent</a>
                    </li>
                    <li class="nav-item px-3 h6">
                        <a class="nav-link<?php echo e($active == 'request' ? ' active callout' : ''); ?>" href="/collector/process">Requests</a>
                    </li>
                    
                    <li class="nav-item px-3 h6">
                        <a class="nav-link<?php echo e($active == 'receipt' ? ' active callout' : ''); ?>" href="#">Receipts</a>
                    </li>
                
                <?php else: ?>
                    <?php if(Auth::user()->inactive == 0): ?>
                        <li class="nav-item px-3 h6">
                            <a class="nav-link<?php echo e($active == 'dashboard' ? ' active callout' : ''); ?>" href="/member/dashboard">Dashboard</a>
                        </li>
                        <?php if(Auth::user()->setup != NULL): ?>
                            <li class="nav-item px-3 h6">
                                <a class="nav-link<?php echo e($active == 'transactions' ? ' active callout' : ''); ?>" href="/member/transactions">Transactions</a>
                            </li>
                            <li class="nav-item px-3 h6">
                                <a class="nav-link<?php echo e($active == 'loan' ? ' active callout' : ''); ?>" href="/member/requests/create">Loan</a>
                            </li>
                            <li class="nav-item px-3 h6">
                                <a class="nav-link<?php echo e($active == 'requests' ? ' active callout' : ''); ?>" href="/member/requests">Requests</a>
                            </li>
                            
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            
            </ul>
        </div>
    </div>
</nav>
<?php endif; ?>