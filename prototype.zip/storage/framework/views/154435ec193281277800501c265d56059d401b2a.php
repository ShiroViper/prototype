<?php $__env->startSection('title'); ?>
<title>Alkansya</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h3 class="header mt-2">Edit User</h3>
<div class="row">
    <div class="col">
        <div class="py-3">
            <a class="btn btn-light border" role="button" href="/admin/users "><i class="fas fa-arrow-left"></i> Back to table</a>
            <div class="float-right">
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col col-md-8">
        <div class="card">
            <?php echo Form::open(['action' => ['UsersController@update', $user->id], 'method' => 'POST']); ?>

            
            <?php echo e(Form::hidden('_method', 'PUT')); ?>

            <div class="card-header d-flex justify-content-between align-items-center">
                <h5>User Information</h5>
                <div class="px-2">
                    <a class="btn btn-outline-danger mr-3" role="button" data-toggle="tooltip" data-placement="top" title="Discard Changes" href="/admin/users/<?php echo e($user->id); ?>"><i class="fas fa-times fa-lg"></i></a>
                    <?php echo e(Form::submit('Save Changes', ['class' => 'btn btn-success edit-button'])); ?>

                </div>
            </div>
            <div class="row">
                <div class="col-sm col-md">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <div class="row">
                                <div class="col">Member ID</div>
                                <div class="col font-weight-bold"><?php echo e($user->id); ?></div>
                            </div>
                        </li>
                        
                        <li class="list-group-item">
                            <div class="row">
                                <div class="col">Last Name</div>
                                <div class="col font-weight-bold">
                                    <?php echo e(Form::text('lname', $user->lname, ['class' => $errors->has('lname') ? 'form-control is-invalid' : 'form-control'])); ?>

                                    
                                    <?php if($errors->has('lname')): ?>
                                        <div class="invalid-feedback"><?php echo e($errors->first('lname')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div class="row">
                                <div class="col">First Name</div>
                                <div class="col font-weight-bold">
                                    <?php echo e(Form::text('fname', $user->fname, ['class' => $errors->has('fname') ? 'form-control is-invalid' : 'form-control'])); ?>

                                    
                                    <?php if($errors->has('fname')): ?>
                                        <div class="invalid-feedback"><?php echo e($errors->first('fname')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div class="row">
                                <div class="col">Middle Name</div>
                                <div class="col font-weight-bold">
                                    <?php echo e(Form::text('mname', $user->mname, ['class' => $errors->has('mname') ? 'form-control is-invalid' : 'form-control'])); ?>

                                    
                                    <?php if($errors->has('mname')): ?>
                                        <div class="invalid-feedback"><?php echo e($errors->first('mname')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div class="row">
                                <div class="col">Email</div>
                                <div class="col font-weight-bold">
                                    <?php echo e(Form::email('email', $user->email, ['class' => $errors->has('email') ? 'form-control is-invalid' : 'form-control'])); ?>

                                    
                                    <?php if($errors->has('email')): ?>
                                        <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div class="row">
                                <div class="col">Contact Number</div>
                                <div class="col font-weight-bold">
                                    <?php echo e(Form::number('cell_num', $user->cell_num, ['class' => $errors->has('cell_num') ? 'form-control is-invalid' : 'form-control'])); ?>

                                    
                                    <?php if($errors->has('cell_num')): ?>
                                        <div class="invalid-feedback"><?php echo e($errors->first('cell_num')); ?></div>
                                    <?php endif; ?>
                                    
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div class="row">
                                <div class="col">Role</div>
                                <div class="col">
                                    <?php echo e(Form::select('user_type', [0 => 'Member', 1 => 'Collector'], $user->user_type, ['class' => 'form-control'])); ?>

                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div class="row">
                                <div class="col">Address</div>
                            </div>
                            <div class="row">
                                <div class="col font-weight-bold">
                                    <?php echo e(Form::textarea('address', $user->address, ['class' => 'form-control', 'rows' => 3, 'placeholder' => 'Street number, Barangay, City/Town, Province, Philippines, Zip Code'])); ?>

                                    <?php if($errors->has('address')): ?>
                                        <div class="invalid-feedback"><?php echo e($errors->first('address')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="card-footer text-muted">
                <small>Account Created: <?php echo e(date("F d, Y", strtotime($user->created_at))); ?>  Time: <?php echo e(date(" h:i:s A", strtotime($user->created_at))); ?></small><br>
                <small>Account Updated: <?php echo e(date("F d, Y", strtotime($user->updated_at))); ?>  Time: <?php echo e(date(" h:i:s A", strtotime($user->updated_at))); ?></small>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<!-- <div class="col-sm col-md">
            <div class="row pr-3 mt-3 form-row">
                <div class="col-md form-group">
                    <label for="noOfDuty">Number of Days off</label>
                    <select name="noOfDuty" id="" class="form-control">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                    </select>
                </div>
            </div>
            <div class="row pr-3 mt-3 form-row">
                <div class="col-md form-group daysOff">
                    <label for="daysOff">Days Off</label>
                    <select name="dutyDate" id="" class="form-control">
                        <option value="0">Sunday</option>
                        <option value="1">Monday</option>
                        <option value="2">Tueday</option>
                        <option value="3">Wednesday</option>
                        <option value="4">Thursday</option>
                        <option value="5">Friday</option>
                        <option value="6">Saturday</option>
                    </select>
                </div>
            </div>
        </div> -->
            
            
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>