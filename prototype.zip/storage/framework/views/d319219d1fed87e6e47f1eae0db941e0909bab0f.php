<?php $__env->startSection('title'); ?>
<title>Alkasnya - Status </title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm col-md-10 col-xl-8">
        <div class="container">
            <div class="row">
                <div class="col-sm">
                Patronage Refund
                </div>
                <div class="col-sm">
                My Loan
                </div>
                <div class="col-sm">
                Savings
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>