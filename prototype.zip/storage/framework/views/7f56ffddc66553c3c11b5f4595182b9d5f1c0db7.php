<?php $__env->startSection('title'); ?>
<title>Alkasnya - View <?php echo e($user->fname); ?>'s Info </title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<div class="row">
    <div class="col-sm col-md-10 col-xl-8">
        <div class="d-flex flex-row">
            <h3 class="header"><?php echo e($user->fname); ?>'s Profile</h3>
            <?php if(Auth::user()->user_type == 1): ?>
                <div class="dropdown">
                    <button class="btn dropdown-toggle ml-3 btn-sm" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-cog"></i>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="change_pass">Change Password</a>
                        <a class="dropdown-item" href="cancel">Deactivate Account</a>
                    </div>
                </div>
            <?php elseif(Auth::user()->user_type == 0): ?>
                <div class="dropdown">
                    <button class="btn dropdown-toggle ml-3 btn-sm" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-cog"></i>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="change_pass">Change Password</a>
                        <a class="dropdown-item" href="cancel">Deactivate Account</a>
                    </div>
                </div>
            <?php else: ?>
                <div class="dropdown">
                    <button class="btn dropdown-toggle ml-3 btn-sm" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-cog"></i>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="change_pass">Change Password</a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <div class="card mt-3">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="header">User information</h5>
                <div class="px-2">
                    <?php if(Auth::user()->user_type == 2): ?>
                        <a href="/admin/profile/<?php echo e($user->id); ?>/edit" class="btn btn-success edit-button" role="button" data-toggle="tooltip" data-placement="top" title="Edit User"><i class="fas fa-user-edit fa-lg"></i></a><br>
                    <?php elseif(Auth::user()->user_type == 1): ?>
                        <a href="/collector/profile/<?php echo e($user->id); ?>/edit" class="btn btn-success edit-button" role="button" data-toggle="tooltip" data-placement="top" title="Edit User"><i class="fas fa-user-edit fa-lg"></i></a><br>
                    <?php else: ?>
                        <a href="/member/profile/<?php echo e($user->id); ?>/edit" class="btn btn-success edit-button" role="button" data-toggle="tooltip" data-placement="top" title="Edit User"><i class="fas fa-user-edit fa-lg"></i></a><br>
                    <?php endif; ?>
                </div>
            </div>
            
            <ul class="list-group list-group-flush">
                <?php if(Auth::user()->user_type == 2): ?>
                    <li class="list-group-item">
                        <div class="row">
                            <div class="col">Account ID</div>
                            <div class="col font-weight-bold"><?php echo e($user->id); ?></div>
                        </div>
                    </li>
                <?php endif; ?>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col">Last Name</div>
                        <div class="col font-weight-bold"><?php echo e($user->lname); ?></div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col">First Name</div>
                        <div class="col font-weight-bold"><?php echo e($user->fname); ?></div>
                    </div>
                </li>
                <?php if($user->mname != NULL): ?>
                    <li class="list-group-item">
                        <div class="row">
                            <div class="col">Middle Name</div>
                            <div class="col font-weight-bold"><?php echo e($user->mname); ?></div>
                        </div>
                    </li>
                <?php endif; ?>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col">Email</div>
                        <div class="col font-weight-bold"><?php echo e($user->email); ?></div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col">Contact Number</div>
                        <div class="col font-weight-bold"><?php echo e($user->cell_num); ?></div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col">Role</div>
                        <div class="col font-weight-bold">
                            <?php if( $user->user_type == 2 ): ?>
                                Admin
                            <?php elseif( $user->user_type == 1 ): ?>
                                Collector
                            <?php else: ?>
                                Member
                            <?php endif; ?>
                        </div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col">Address</div>
                        <div class="col font-weight-bold"><?php echo e($user->address); ?></div>
                    </div>
                    
                </li>
            </ul>
            <div class="card-footer text-muted">
                <small>Account Created: <?php echo e(date("F d, Y", strtotime($user->created_at))); ?>  Time: <?php echo e(date(" h:i:s A", strtotime($user->created_at))); ?></small><br>
                <small>Account Updated: <?php echo e(date("F d, Y", strtotime($user->updated_at))); ?>  Time: <?php echo e(date(" h:i:s A", strtotime($user->updated_at))); ?></small>
            </div>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>