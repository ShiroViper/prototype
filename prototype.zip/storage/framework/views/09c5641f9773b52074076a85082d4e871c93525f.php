<?php $__env->startSection('title'); ?>
    <title>Transactions</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h3 class="header mt-2">Member Request</h3>
<div class="table-responsive">
    <table class="table table-striped mt-3">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Contact Details</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($memReq) > 0): ?>
                <?php $__currentLoopData = $memReq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($req->lname); ?>, <?php echo e($req->fname); ?> <?php echo e($req->mname); ?> </td>
                    <td><?php echo e($req->email); ?></td>
                    <td><?php echo e($req->contact); ?></td>
                    <td>
                        <a href="<?php echo e(action('MemberRequestController@accept', $req->id)); ?>" class="btn btn-primary m-1" role="button">Accept</a>
                        <a href="<?php echo e(action('MemberRequestController@decline', $req->id)); ?>" class="btn btn-outline-secondary m-1" role="button">Decline</button>
                    </td>
                </tr>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <tr>
                <td colspan="100%" class="text-center"><h4 class="text-muted">No Entries Found</h4></td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<h3 class="header mt-3">Transactions</h3>
<div class="table-responsive">
    <table class="table table-striped mt-3">
        <thead>
            <tr>
                <th>Account</th>
                <th>Date & Time</th>
                <th>Member</th>
                <th>Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($transactions) > 0): ?>
                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php if($trans->trans_type == 1 ): ?>
                        <td>Savings: Deposit</td>
                    <?php else: ?>
                        <td>My Loan: Loan Payment</td>
                    <?php endif; ?>
                    <td><?php echo e(date("h:i A M d, Y", strtotime($trans->created_at))); ?></td>
                    <td><?php echo e($trans->lname); ?>, <?php echo e($trans->fname); ?> <?php echo e($trans->mname); ?> </td>
                    <td>₱ <?php echo e(number_format($trans->amount, 2)); ?></td>
                </tr>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <tr>
                <td colspan="100%" class="text-center"><h4 class="text-muted">No Entries Found</h4></td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="d-flex justify-content-center mt-3">
    <?php echo e($transactions->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>