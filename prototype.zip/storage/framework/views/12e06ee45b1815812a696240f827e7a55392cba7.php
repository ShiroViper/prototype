<?php $__env->startSection('title'); ?>
    <title>Failed Expected Deposit Accounts</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row pt-5">
        <div class="col">
            <div class="card">
                <h6 class="card-header">Failed Expected Deposit Accounts</h6>
                <div class="container">
                    <div class="table-responsive">
                        <table class="table" style="text-align:center">
                            <thead>
                                <tr>
                                    <th>Due Date</th>
                                    <th>Member ID</th>
                                    <th>Member Name</th>
                                    <th>Collector Name</th>
                                    <th>Outstanding Balance</th>
                                    <th>Remaining Balance</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($failures) > 0): ?>
                                    <?php $__currentLoopData = $failures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $failed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(date("M d, Y", strtotime($failed->due_date))); ?></td>
                                            <td><?php echo e($failed->member_id); ?> </td>
                                            <td><?php echo e($failed->lname); ?>, <?php echo e($failed->fname); ?></td>
                                            <td><?php echo e($failed->col_lname); ?>, <?php echo e($failed->fname); ?> </td>
                                            <td><?php echo e($failed->balance); ?> Php</td>
                                            <td>For Deposit</td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="100%" class="text-center"><h4 class="text-muted">No Entries Found</h4></td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-center mt-3">
                        <?php echo e($failures->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>