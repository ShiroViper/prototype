<?php $__env->startSection('title'); ?>
<title>Alkansya - Requests</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h3 class="header mt-2">Requests</h3>

<?php if(count($pending_col) > 0): ?>
    <div class="row pt-3">
        <div class="col">
            <div class="card">
                <h6 class="card-header">Pending Money</h6>
                <div class="container">
                    <div class="table-responsive">
                        <table class="table table-hover mt-3">
                            <thead>
                                <tr>
                                    <th>Money Received</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($pending_col) > 0): ?>
                                    <?php $__currentLoopData = $pending_col; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($item->transfer == 1): ?>
                                            
                                            <tr >
                                                <td>₱ <?php echo e(number_format($item->loan_amount, 2)); ?></td>
                                                <td class="d-flex flex-row">
                                                    <a class="btn btn-outline-primary mx-2 no-modal" role="button" href="/collector/receive/<?php echo e($item->request_id); ?>/accept">Accept</a>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="100%" class="text-center"><h4 class="text-muted">No Entries Found</h4></td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-center mt-3">
                        <?php echo e($pending_col->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>



    <div class="row pt-3">
        <div class="col">
            <div class="card">
                <h6 class="card-header">Pending Confirmation</h6>
                <div class="container">
                    <div class="table-responsive">
                        <table class="table table-hover mt-3">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($confirmed) > 0): ?>
                                    <?php $__currentLoopData = $confirmed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->lname.', '. $item->fname. ' '. $item->mname); ?></td>
                                            <td>₱ <?php echo e(number_format($item->amount, 2)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="100%" class="text-center"><h4 class="text-muted">No Entries Found</h4></td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-center mt-3">
                        <?php echo e($confirmed->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>



<div class="row pt-3">
    <div class="col">
        <div class="card">
            <h6 class="card-header">Money Received</h6>
            <div class="container">
                <div class="table-responsive">
                    <table class="table table-hover mt-3">
                        <thead>
                            <tr>
                                <th>Received Date&Time</th>
                                <th>Name</th>
                                <th>Amount</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($received_col) > 0): ?>
                                <?php $__currentLoopData = $received_col; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <tr>
                                        <td><?php echo e(date('h:i A F, d Y', strtotime($item->updated_at))); ?> </td>
                                        <td><?php echo e($item->lname.', '. $item->fname. ' '.$item->mname); ?></td>
                                        <td>₱ <?php echo e(number_format($item->loan_amount, 2)); ?></td>
                                        <td><a class="btn btn-outline-primary mx-2 no-modal" role="button" href="/collector/receive/<?php echo e($item->request_id); ?>/accept">Transfer</a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr>
                                <td colspan="100%" class="text-center"><h4 class="text-muted">No Entries Found</h4></td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-center mt-3">
                    <?php echo e($received_col->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>