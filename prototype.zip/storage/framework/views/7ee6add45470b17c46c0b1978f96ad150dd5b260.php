

<?php if(session('success')): ?>
    <div class="alert alert-success fade show pop-messages position-absolute w-50 text-center shadow" role="alert">
        <strong> <?php echo e(session('success')); ?> </strong>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger fade show pop-messages position-absolute w-50 text-center shadow" role="alert">
        <strong> <?php echo e(session('error')); ?> </strong>
    </div>
<?php endif; ?>