<?php $__env->startSection('title'); ?>
<title>Alkansya - Request Loan</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php if(!$unpaid): ?>
    <h3 class="header mt-2">Request Loan</h3>
    <div class="row">
        <div class="col-sm-10 col-md-7 col-lg-5 my-3 order-2 order-md-1">  
            <?php echo Form::open(['action' => 'LoanRequestsController@store', 'method' => 'POST']); ?>

            <?php echo csrf_field(); ?>
            <?php echo e(Form::hidden('token', $token)); ?>


            <?php echo e(Form::label('amount', 'Loan Amount', ['class' => 'h6'])); ?>

            <div class="form-group">
                    <?php echo e(Form::number('amount', '', ['class' => $errors->has('amount') ? 'form-control is-invalid' : 'form-control', 'placeholder' => 'Enter amount', 'min'=>'5', 'step' => '.01', 'required'])); ?>

                <?php if($errors->has('amount')): ?>
                    <div class="invalid-feedback"><?php echo e($errors->first('amount')); ?></div>
                <?php endif; ?>
            </div>

            <?php echo e(Form::label('months', 'Months Payable', ['class' => 'h6'])); ?>

            <div class="form-group">
            <?php echo e(Form::number('months', '', ['class' => $errors->has('months') ? 'form-control is-invalid' : 'form-control', 'min'=>'1', 'max'=>'12', 'required'])); ?>

                <?php if($errors->has('months')): ?>
                    <div class="invalid-feedback"><?php echo e($errors->first('months')); ?></div>
                <?php endif; ?>
            </div>

            <?php echo e(Form::label('reason', 'Reason', ['class' => 'h6'])); ?>

            <div class="form-group">
                <select name="reason" id="reason" class="form-control" required>
                    <option selected hidden>-- Select Reason --</option>
                    <option value="For Personal Use">For Personal Use</option>
                    <option value="For Emergency Use">For Emergency Use</option>
                    <option value="3">Other</option>
                </select>
                <textarea name="other" id="other" rows="1" class="form-control mt-2" placeholder="Other (please specify)"></textarea>
            </div>
            
            
            <label for="pass"> Password</label>
            <div class="form-group">
                <input type="password" name="pass" class="form-control" required>
            </div>

            <div class="form-group">
                <div class="form-check">
                    <?php echo Form::checkbox('agreement', 'yes', false, ['class' => 'form-check-input', 'id' => 'agreement', 'required']); ?>

                    <?php echo e(Form::label('agreement', 'I agree with the ')); ?> 
                    <?php echo "<a href='/terms' target='_blank'>Terms and Conditions</a>"; ?>

                </div>
            </div>
            <?php echo e(Form::submit('Request', ['class' => 'btn btn-primary'])); ?>

            
            <?php echo Form::close(); ?>

        </div>
        <div class="col-sm col-md offset-lg-1 col-lg-4 my-3 order-1 order-md-2">  
            <div class="card shadow">
                <div class="card-body note-box border-warning border-left d-flex flex-column rounded">
                    <div class="h4">
                        
                        <?php echo e($savings && $savings->savings != null ? '₱'.$savings->savings : 'No Savings'); ?>

                    </div>
                    <div>Current Savings</div>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>
    
    <div class="failed-loan d-flex justify-content-center align-items-center">
        <h6 class="display-5 header text-center">Please settle your unfinished loan first.</h6>
        
        
    </div>
<?php endif; ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>