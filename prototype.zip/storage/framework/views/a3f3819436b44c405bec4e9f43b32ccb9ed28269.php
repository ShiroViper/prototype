<?php $__env->startSection('title'); ?>
<title>Alkasnya</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPrepend('scripts'); ?>
    <script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.0/fullcalendar.min.js"></script>
<?php $__env->stopPrepend(); ?> 
<div class="row">
    <div class="col">
        <div class="py-3">
            <a class="btn btn-light border" role="button" href="/member/profile"><i class="fas fa-arrow-left"></i>  Back </a>
        </div>
    </div>
</div>
<div class="row full-view">
    <div class="col-sm col-md-6 col-xl-4">
        <h3 class="header pb-3">Change Password</h3>
        <form method="POST" action="<?php echo e(action('MemberController@change')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="password">Old Password</label>
            <input name="old_password" type="password" class="form-control" autofocus required>
        </div>
        <div class="form-group">
            <label for="password">New Password</label>
            <input name="password" type="password" id="password" onChange="passwordChecker();" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" value="<?php echo e(isset($message) ? '' : old('password')); ?>" autofocus required>
            <?php if( $errors->has('password') ): ?>
                <div class="invalid-feedback"><?php echo e($errors->first('password')); ?></div>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label for="password_confirmation">Confirm Password</label>
            <input type="password" id="cpassword" onChange="passwordChecker();" name="password_confirmation" id="password_confirmation" class="form-control" required>
            <div id="password-checker"></div>
        </div>
            <button type="submit" class="btn btn-primary px-4 member-setup-btn" disabled>Change Password</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>