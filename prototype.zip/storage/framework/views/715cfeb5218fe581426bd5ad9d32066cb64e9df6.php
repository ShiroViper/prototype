<?php $__env->startSection('title'); ?>
<title>Alkansya - Requests</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col">
            <h3 class="header float-left">Requests</h3>
            <div class="badge badge-pill badge-primary ml-3 px-2">Compound Interest: 6%</div>
            
        <?php if(!$unpaid): ?>
            <div class="float-right">
                <a class="badge badge-pill badge-success shadow border py-2" role="button" data-toggle="tooltip" data-placement="top" title="Add Loan Request" href="/member/requests/create"><span class="h5"><i class="fas fa-plus fa-lg"></i></a>
            </div>
        <?php endif; ?>
    </div>
</div>


<?php if(count($pending_mem_con)): ?>
    <div class="row pt-3 mb-5">
        <div class="col">
            <div class="card">
                <h6 class="card-header">Pending Confirmation</h6>
                <div class="container">
                    <div class="table-responsive">
                        <table class="table table-hover" >
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Transaction Type</th>
                                    <th>Amount Sent</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pending_mem_con; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->lname. ', '.$item->fname.' '.$item->mname); ?></td>
                                        <?php if($item->trans_type == 1): ?>
                                            <td>Deposit</td>
                                        <?php else: ?>
                                            <td>Loan Payment</td>
                                        <?php endif; ?>
                                        <td>₱ <?php echo e(number_format($item->amount, 2)); ?> </td>
                                        
                                        <td class="d-flex flex-row">
                                            <?php if($item->trans_type == 1 ): ?>
                                                <a class="btn btn-outline-primary mx-2 no-modal" role="button" href="/member/sent/<?php echo e($item->id); ?>/d_accept">Confirm</a>
                                            <?php else: ?>
                                                <a class="btn btn-outline-primary mx-2 no-modal" role="button" href="/member/sent/<?php echo e($item->id); ?>/accept">Confirm</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-center mt-3">
                        <?php echo e($pending_mem_con->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if(count($pending_mem_receive) > 0): ?>
    <div class="row pt-3">
        <div class="col">
            <div class="card">
                <h6 class="card-header">Pending Money</h6>
                <div class="container">
                    <div class="table-responsive">
                        <table class="table table-hover" >
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Money Received</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($pending_mem_receive) > 0): ?>
                                    <?php $__currentLoopData = $pending_mem_receive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->lname); ?>, <?php echo e($item->fname); ?> <?php echo e($item->mname); ?> </td>
                                        <td>₱ <?php echo e(number_format($item->loan_amount, 2)); ?> </td>
                                        <td class="d-flex flex-row">
                                            <a class="btn btn-outline-primary mx-2 no-modal" role="button" href="/member/receive/<?php echo e($item->request_id); ?>/accept">Accept</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="100%" class="text-center"><h4 class="text-muted">No Entries Found</h4></td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-center mt-3">
                        <?php echo e($pending_mem_receive->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<div class="row mt-3">
    <div class="col">
        <div class="card">
            <h6 class="card-header">Pending Requests</h6>
            <div class="container">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Date Requested</th>
                                <th>Loan Requested</th>
                                <th>Payables</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($pending) > 0): ?>
                                <?php $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <tr>
                                        <td><?php echo e(date("h:i A  F d, Y", strtotime($item->created_at))); ?></td>
                                        <td>₱ <?php echo e(number_format($item->loan_amount, 2)); ?></td>
                                        <td><?php echo e($item->days_payable); ?> Months</td>
                                        <td>
                                            <?php echo Form::open(['action' => ['LoanRequestsController@destroy', $item->id], 'method' => 'POST']); ?>

                                                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                                <?php echo e(Form::submit('Cancel Request', ['class' => 'btn btn-outline-secondary no-modal'])); ?>

                                            <?php echo Form::close(); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr>
                                <td colspan="100%" class="text-center"><h4 class="text-muted">No Entries Found</h4></td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-center mt-3">
                    <?php echo e($pending->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mt-5">
        <div class="col">
            <div class="card">
                <h6 class="card-header">Requests History</h6>
                <div class="container">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Date Approved</th>
                                    <th>Loan Amount</th>
                                    <th>Payables</th>
                                    <th>Status</th>
                                    <th>Money Received</th>
                                    <th>Paid</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($requests) > 0): ?>
                                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($request->paid): ?>
                                            <tr class="clickable" data-toggle="modal" data-target="#histReqModal" data-id="<?php echo e($request->id); ?>" data-cdate="<?php echo e(date('F d, Y H:i:s A', strtotime($request->created_at))); ?>" data-udate="<?php echo e(date('F d, Y H:i:s A', strtotime($request->updated_at))); ?>" data-amount="<?php echo e($request->loan_amount); ?>" data-dp="<?php echo e($request->days_payable); ?>" data-conf="<?php echo e($request->confirmed == 1 ? 'Approved' : 'Declined'); ?>" data-desc="<?php echo e($request->description); ?>" data-paid="<?php echo e($request->paid ? ($request->confirmed ? 'Yes' : '') : 'Ongoing'); ?>">
                                        <?php else: ?>
                                            <tr class="table-secondary font-weight-bold clickable" data-toggle="modal" data-target="#histReqModal"  data-id="<?php echo e($request->id); ?>" data-cdate="<?php echo e(date('F d, Y H:i:s A', strtotime($request->created_at))); ?>" data-udate="<?php echo e(date('F d, Y H:i:s A', strtotime($request->updated_at))); ?>" data-amount="<?php echo e($request->loan_amount); ?>" data-dp="<?php echo e($request->days_payable); ?>" data-conf="<?php echo e($request->confirmed == 1 ? 'Approved' : 'Declined'); ?>" data-desc="<?php echo e($request->description); ?>" data-paid="<?php echo e($request->paid ? ($request->confirmed ? 'Yes' : '') : 'Ongoing'); ?>">
                                        <?php endif; ?>
                                            <td><?php echo e(date("h:i A  F d, Y", strtotime($request->updated_at))); ?></td>
                                            <td>₱ <?php echo e(number_format($request->loan_amount, 2)); ?></td>
                                            <td><?php echo e($request->days_payable); ?> Months</td>
                                            <td><?php echo e($request->confirmed ? 'Approved' : 'Declined'); ?></td>
                                            <td><?php echo e($request->received ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($request->paid ? ($request->confirmed ? 'Yes' : '') : 'Ongoing'); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="100%" class="text-center"><h4 class="text-muted">No Entries Found</h4></td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-center mt-3">
                        <?php echo e($requests->links()); ?>

                    </div>  
                </div>
            </div>
        </div>
    </div>

<div class="modal fade" id="histReqModal" tabindex="-1" role="dialog" aria-labelledby="histReqModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="histReqModalLabel">View Request</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="alert alert-warning loan-unpaid text-center">  
                </div>
                <div class="row">
                    <div class="col-4 text-right">
                        <span class="">Status: </span>
                    </div>
                    <div class="col">
                        <span class="font-weight-bold loan-conf"></span>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-4 text-right">
                        <span class="">Confirmed on: </span>
                    </div>
                    <div class="col">
                        <span class="font-weight-bold loan-udate"></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4 text-right">
                        <span class="">Loan Amount: </span>
                    </div>
                    <div class="col">
                        <span class="font-weight-bold loan-amount"></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4 text-right">
                        <span class="">Months Payable: </span>
                    </div>
                    <div class="col">
                        <span class="font-weight-bold loan-dp"></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4 text-right">
                        <span class="">Paid: </span>
                    </div>
                    <div class="col">
                        <span class="font-weight-bold loan-paid"></span>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-4 text-right">
                        <span class="">Date Created: </span>
                    </div>
                    <div class="col">
                        <span class="font-weight-bold loan-cdate"></span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>