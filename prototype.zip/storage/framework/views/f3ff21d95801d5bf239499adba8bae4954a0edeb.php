<?php $__env->startSection('title'); ?>
<title>Alkansya - Status </title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-6">
        <div class="container">
            <div class="row">
                <div class="col-3">
                    <p>Patronage Refund</p>
                    <?php if($patronage->patronage_refund): ?>
                        <?php echo e($patronage->patronage_refund); ?>

                    <?php else: ?>
                        No patronage refund
                    <?php endif; ?>
                </div>
                <div class="col-3">
                    <p>My Loan(balance)</p>
                    <?php if($loan): ?>
                        <?php echo e($loan->balance); ?>

                    <?php else: ?>
                        No current Loan
                    <?php endif; ?>
                </div>
                <div class="col-3">
                    <p>Savings</p>
                    <?php if($savings->savings): ?>
                        <?php echo e($savings->savings); ?>

                    <?php else: ?>
                        No current savings
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="col-6">
        Note: patronage refund can be claim in the end of december or the distribution of savings if your savings is beyond 1825 pesos. <br>
        patronage refund available if their is atleast one loan. <br>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>