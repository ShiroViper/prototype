<?php $__env->startSection('title'); ?>
<title>Alkansya - Requests</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(count($pending_cancel) > 0): ?>
<h3 class="header mt-2">Request for Account Deactivation</h3>
<div class="row mb-5">
    <div class="col">
        
        <div class="container">
            <div class="table-responsive">
                <table class="table table-hover mt-3">
                    <thead>
                        <tr>
                            <th>Date Requested</th>
                            <th>Name</th>
                            <th>Comments (testing only)</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pending_cancel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr >
                                <td><?php echo e(date("F d, Y", strtotime($item->created_at))); ?></td>
                                <td><?php echo e($item->user->lname.', '. $item->user->fname.' '. $item->user->mname); ?></td>
                                <td><?php echo e($item->comments); ?> </td>
                                <td class="d-flex flex-row">
                                    <a class="btn btn-outline-primary mx-2 no-modal" role="button" href="/admin/cancel/<?php echo e($item->id); ?>/accept">Accept</a>
                                    <a class="btn btn-outline-secondary mx-2 no-modal" role="button" href="/admin/cancel/<?php echo e($item->id); ?>/reject">Decline</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="d-flex justify-content-center mt-3">
                <?php echo e($pending_cancel->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<h3 class="header mt-2">Requests</h3>
<div class="row">
    <div class="col">
        
        <div class="container">
            <div class="table-responsive">
                <table class="table table-hover mt-3">
                    <thead>
                        <tr>
                            <th>Date Requested</th>
                            <th>Member</th>
                            <th>Loan Requested</th>
                            <th>Payables</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($pending) > 0): ?>
                            <?php $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <tr >
                                    <td><?php echo e(date("h:i A  F d, Y", strtotime($item->created_at))); ?></td>
                                    <td><?php echo e($item->user->lname.', '. $item->user->fname.' '. $item->user->mname); ?></td>
                                    <td>₱ <?php echo e(number_format($item->loan_amount, 2)); ?></td>
                                    <td><?php echo e($item->days_payable); ?> Months</td>
                                    <td class="d-flex flex-row">
                                        <a class="btn btn-outline-primary mx-2 no-modal" role="button" href="/admin/requests/<?php echo e($item->id); ?>/accept">Accept</a>
                                        <a class="btn btn-outline-secondary mx-2 no-modal" role="button" href="/admin/requests/<?php echo e($item->id); ?>/reject">Decline</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="100%" class="text-center"><h4 class="text-muted">No Entries Found</h4></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="d-flex justify-content-center mt-3">
                <?php echo e($pending->links()); ?>

            </div>
        </div>
    </div>
</div>

<h3 class="header mt-5">Requests History</h3>
<div class="row">
    <div class="col">
        
        <div class="container">
            <div class="table-responsive">
                <table class="table table-hover mt-3">
                    <thead>
                        <tr>
                            <th>Date Approved</th>
                            <th>Member</th>
                            <th>Loan Amount</th>
                            <th>Payables</th>
                            <th>Status</th>
                            <th>Money Received</th>
                            <th>Paid</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($requests) > 0): ?>
                            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <tr >
                                    <td><?php echo e(date("h:i A  F d, Y", strtotime($request->updated_at))); ?></td>
                                    <td><?php echo e($request->user->lname); ?>, <?php echo e($request->user->fname); ?> <?php echo e($request->user->mname); ?> </td>
                                    <td>₱ <?php echo e(number_format($request->loan_amount  * 0.06 * $request->days_payable + $request->loan_amount, 2)); ?></td>
                                    <td><?php echo e($request->days_payable); ?> Months</td>
                                    <td><?php echo e($request->confirmed ? 'Approved' : 'Declined'); ?></td>
                                    <td><?php echo e($request->received ? 'Yes' : ($request->confirmed ? 'No': 'N/A')); ?> </td>  
                                    <td><?php echo e($request->confirmed ? ($request->paid ? 'Yes' : 'Ongoing') : 'N/A'); ?></td>
                                    
                                    <?php if($request->received != 1 && $request->confirmed != 0): ?>
                                        <td><a class="btn btn-outline-primary mx-2 no-modal" role="button" href="/admin/process/<?php echo e($request->id); ?>/edit">Transfer</a></td>
                                    <?php else: ?>
                                        <td><span class="badge badge-success"><small>Money Transferred</small></span></td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="100%" class="text-center"><h4 class="text-muted">No Entries Found</h4></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="d-flex justify-content-center mt-3">
                <?php echo e($requests->links()); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
<?php $__env->stopPush(); ?>
    



                
                
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>