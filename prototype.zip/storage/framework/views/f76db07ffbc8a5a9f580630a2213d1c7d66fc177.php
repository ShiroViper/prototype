<?php $__env->startSection('title'); ?>
<title>Alkansya - Status </title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php if($account_status): ?>
    <div class="col-6">
        <?php if($account_status->confirmed == NULL): ?>
        <h2 class="display-5 header">Requires Confirmation from the administration</h2>
        <p>If you dont request this cancellation of account click <a href="/member/cancel/destroy"> Revoke Cancellation Request </a> . </p>
        <?php elseif($account_status->confirmed == 1): ?>
            <h2>Account has been canceled by the administration</h2>
        <?php endif; ?>
    </div>
<?php else: ?>
<div class="jumbotron jumbotron-fluid border rounded">
    <div class="container">
            <h2 class="display-4 header">Deactivate Account</h2>
            
            <div class="lead">
                <p>Once your account is approved for cancellation, you can become a member once again after the current year ends.</p>
                <p><b class="h5">Patronage refund</b> can be claimed if your <b class="h5">savings</b> has reached the minimun ₱1825.</p>
                <p><b class="h5">Savings</b> can be claim without deduction.</p>
                <p>Cancellation of account is available when their are no current loan.</p>
                <p>This request is subject to change</p>
            </div>           
    </div>
</div>
<div class="row">
    <div class="col">
        <div class="py-3">
            <a class="btn btn-light border" role="button" href="/member/profile"><i class="fas fa-arrow-left"></i>  Back </a>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-sm col-md-10 col-xl-8">
        <h5 class="h5 pb-3">Request for Deactivation of Account</h5>
        <?php echo Form::open(['action'=> ['MemberController@update'], 'method'=>'POST']); ?>

        <?php echo csrf_field(); ?>
        <?php echo e(Form::hidden('token', $token)); ?>

        
        <div class="form-group">
            <?php echo e(Form::label('reason', 'Reason', ['class' => 'h6'])); ?>

            <?php echo e(Form::textarea('reason', '', ['class' => $errors->has('reason') ? 'form-control is-invalid' : 'form-control', 'rows' => 2, 'required'])); ?>

            <?php if($errors->has('reason')): ?>
                <div class="invalid-feedback"><?php echo e($errors->first('reason')); ?></div>
            <?php endif; ?>
        </div>
    
        <div class="form-group">
            <label for="password" class="h6"> Password</label>
            <input id="password" type="password" name="pass" class="form-control" required>
            <?php if($errors->has('pass')): ?>
                <div class="invalid-feedback"><?php echo e($errors->first('pass')); ?></div>
            <?php endif; ?>
        </div>
    
        <?php echo e(Form::submit('Submit Request', ['class' => 'btn btn-primary autocomplete-btn'])); ?>

    
        <?php echo Form::close(); ?>

    </div>
</div>
<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>