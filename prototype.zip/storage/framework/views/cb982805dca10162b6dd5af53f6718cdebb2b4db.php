<?php $__env->startSection('title'); ?>
<title>Alkansya - Add Member</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if( count($users) > 0 ): ?>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            // Get the last ID number
            $last_id = $user->id;

            $get_year = now()->year - 2000;
            $result = floor($last_id/10000);
            // result in 2 digit number

            // echo $result."<br>"; 
            
            if ( $result == $get_year ) {
                // echo "true";
                $ctr = $result * 10000;
                $result = ($get_year*10000)+(($last_id - $ctr)+1);

            } else {
                // echo "false";
                $result = $get_year*10000;
                $result++;
            }
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<h3 class="header mt-2">Add Member</h3>
    <div class="row">
        <div class="col-lg col-xl-10 m-3">  
            <?php echo Form::open(['action' => 'UsersController@store', 'method' => 'POST']); ?>

            <?php echo csrf_field(); ?>
            <div class="row">
                
                <div class="col-sm col-md-6">
                    <div class="form-group">
                        <?php echo e(Form::label('type', 'Account Type', ['class' => 'h6'])); ?>

                        <?php echo e(Form::select('type', [0 => 'Member', 1 => 'Collector'], 0, ['class' => 'form-control'])); ?>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg">
                    <div class="form-group">
                        <?php echo e(Form::label('lname', 'Last Name', ['class' => 'h6'])); ?>

                        <?php echo e(Form::text('lname', '', ['class' => $errors->has('lname') ? 'form-control is-invalid' : 'form-control'])); ?>

                        <?php if($errors->has('lname')): ?>
                            <div class="invalid-feedback"><?php echo e($errors->first('lname')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg">
                    <div class="form-group">
                        <?php echo e(Form::label('fname', 'First Name', ['class' => 'h6'])); ?>

                        <?php echo e(Form::text('fname', '', ['class' => $errors->has('fname') ? 'form-control is-invalid' : 'form-control'])); ?>

                        <?php if($errors->has('fname')): ?>
                            <div class="invalid-feedback"><?php echo e($errors->first('fname')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg">
                    <div class="form-group">
                        <?php echo e(Form::label('mname', 'Middle Name', ['class' => 'h6'])); ?>

                        <small class="text-muted ml-2">(Optional)</small>
                        <?php echo e(Form::text('mname', '', ['class' => $errors->has('mname') ? 'form-control is-invalid' : 'form-control'])); ?>

                        <?php if($errors->has('mname')): ?>
                            <div class="invalid-feedback"><?php echo e($errors->first('mname')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <?php echo e(Form::label('email', 'Email', ['class' => 'h6'])); ?>

                        <?php echo e(Form::email('email', '', ['class' => $errors->has('email') ? 'form-control is-invalid' : 'form-control'])); ?>

                        <?php if($errors->has('email')): ?>
                            <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <?php echo e(Form::label('cell_num', 'Contact Number', ['class' => 'h6'])); ?>

                        <?php echo e(Form::text('cell_num', '', ['class' => $errors->has('cell_num') ? 'form-control is-invalid' : 'form-control'])); ?>

                        <?php if($errors->has('cell_num')): ?>
                            <div class="invalid-feedback"><?php echo e($errors->first('cell_num')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <?php echo e(Form::label('address', 'Complete Address', ['class' => 'h6 mb-0'])); ?>

                        <div class="mb-2"><small class="text-muted">Street number, Barangay, City/Town, Province, Philippines, Zip Code</small></div>
                        <?php echo e(Form::textarea('address', '', ['class' => $errors->has('address') ? 'form-control is-invalid' : 'form-control', 'rows' => 2])); ?>

                        <?php if($errors->has('address')): ?>
                            <div class="invalid-feedback"><?php echo e($errors->first('address')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-lg-center">
                <?php echo e(Form::submit('Create', ['class' => 'btn btn-block btn-primary align-content-center my-3'])); ?>

            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
        
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>